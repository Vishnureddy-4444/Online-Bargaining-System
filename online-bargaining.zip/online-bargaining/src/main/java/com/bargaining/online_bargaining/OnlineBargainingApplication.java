package com.bargaining.online_bargaining;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBargainingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBargainingApplication.class, args);
	}

}
