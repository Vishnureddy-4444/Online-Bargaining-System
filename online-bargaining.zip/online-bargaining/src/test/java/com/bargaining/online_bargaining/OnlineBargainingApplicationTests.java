package com.bargaining.online_bargaining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBargainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
